INSTALLATION
------------

Clone project from github to your local directory

.. code:: bash

    $> git clone https://github.com/prikid/captcha_solver_demo.git

    $> cd captcha_solver_demo && pip install .


install tesseract > 4.0

