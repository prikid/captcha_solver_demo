
INSTALLATION

    clone project from github to your local directory

    >>> git clone https://github.com/prikid/capthca_solver_demo.git

    install package

    >>> pip install dist/captcha_solver-0.1-py2.py3-none-any.whl

    install tesseract > 4.0

