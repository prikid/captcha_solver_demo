INSTALLATION
------------

Clone project from github to your local directory

.. code:: bash

    git clone https://github.com/prikid/captcha_solver_demo.git

Install package

.. code:: bash

    pip install dist/captcha_solver-0.1-py2.py3-none-any.whl


install tesseract > 4.0

