from captcha_solver import *
name = 'captcha_solver'

