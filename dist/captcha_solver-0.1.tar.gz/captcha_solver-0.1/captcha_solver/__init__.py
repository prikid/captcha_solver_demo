from .captcha_solver import solve_captcha


